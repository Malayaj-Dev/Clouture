const mongoose = require('mongoose');
var MongoClient = require('mongodb').MongoClient;

const connectDB = async () => {
  const conn = await mongoose.connect(process.env.MONGO_URI, {
    /* useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
    useUnifiedTopology: true */
  });

  console.log(`MongoDB Connected: ${conn.connection.host}`.cyan.underline.bold);};

const buildConnection = function() {
    return new Promise(function(resolve, reject) {
        MongoClient.connect(process.env.MONGO_URI,{ useNewUrlParser: true, useUnifiedTopology: true }, function(err, db) {
            if (err) throw err;
            var dbo = db.db("cloturedb");
            //var dbo = db.db("CSMSAdmin");
            resolve(dbo);
        });
    });
}

module.exports = {connectDB,buildConnection};
