const crypto = require('crypto');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
//const sendEmail = require('../utils/sendEmail');
const Employee = require('../models/employee');
const { ObjectId } = require('mongodb');
const { request } = require('http');



// @desc      Register employee
// @route     POST /api/v1/employee/register
// @access    Public
exports.register = asyncHandler(async (req, res, next) => {
  console.log(req.body);
  const { Name, Email, password, Role } = req.body;

  // Create employee
  const employee = await Employee.create({
    Name,
    Email,
    password,
    Role
  });
  sendTokenResponse(employee, 200, res);
});


