const ErrorResponse = require('../utils/errorResponse');
const { returnJsonResponse } = require('../utils/response');
const asyncHandler = require('../middleware/async');
const User = require('../models/user');
const otpGenerator = require('otp-generator')
const { ObjectId } = require('mongodb');
const { buildConnection } = require('../config/db');

exports.userRegistration = asyncHandler(async (req, res, next) => {
  let data = req.body;
  let user = await User.create(data);
  returnJsonResponse(req, res, { Status: 200, Message: "Success", Data: { _id: user._id.toString() } });
});

exports.getAllUser = asyncHandler(async (req, res, next) => {
  try {
    let user = await User.find();
    returnJsonResponse(req, res, { Status: 200, Message: "Success", Data: user });
  } catch (error) {
    returnJsonResponse(req, res, { Status: 500, Message: "Internal server error", Data: {} });
  }
});
