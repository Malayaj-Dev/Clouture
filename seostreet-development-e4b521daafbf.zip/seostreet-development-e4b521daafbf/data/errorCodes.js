module.exports = [
  //300-399 for
  //400-499 for U ser & User Validation
  //500-599 for Machine
  //600-699 for Admin
    {
      "statuscode": "403",
      "msg": "access denied"
    },
    {
      "statuscode": "405",
      "msg": "Email is required"
    },
    {
      "statuscode": "406",
      "msg": "Password is incorrect"
    },
    {
      "statuscode": "407",
      "msg": "Invalid credentials"
    },
    {
      "statuscode": "408",
      "msg": "Email not found"
    },
    {
      "statuscode": "410",
      "msg": "Security alert. It looks like someone logged into your account from a device" 
       //"device name" on "date" at "time". The login took place somewhere near "place name."
    },
    {
      "statuscode": "412",
      "msg": "Network error"
    },
    {
      "statuscode": "414",
      "msg": "No Payment History."
    },
    {
      "statuscode": "415",
      "msg": "You haven't set up any payment methods yet."
    },
    
    {
      "statuscode": "416",
      "msg": "Passwords must contain a letter, number, and punctuation character."
    },
    {
      "statuscode": "417",
      "msg": "Do you really want to cancel charging."
    },
    
    {
      "statuscode": "513",
      "msg": "No results found for {Machine type} with the Id of {id}"
    },
    {
      "statuscode": "514",
      "msg": "The machine is not available at this moment."
    },
    {
      "statuscode": "611",
      "msg": "Sorry! No results found for {search}. Please check the spelling or type any other keyword to search."
    },
   
    
    
    {
      "statuscode": "501",
      "msg": "Something went wrong. Please try again later."
    },
    {
      "statuscode": "505",
      "msg": "Oops! We will have to reload this page because of inactivity. Please click Ok to retry."
    },
    {
      "statuscode": "423",
      "msg": "Please try using another payment method."
    },
    {
      "statuscode": "607",
      "msg": "Transaction Failed. If you have been charged, a refund shall be processed within 5-7 working days. Click to retry or try another payment method."
    },
    {
      "statuscode": "608",
      "msg": "Help us serve you better! Share your vehicle make and model, and set location preferences for customized service and offers."
    },
    {
      "statuscode": "509",
      "msg": "No coupons available."
    },
    
    {
      "statuscode": "301",
      "msg": "To protect your security, Volt Panda does not store your UPI PIN or full bank account number."
    },
    {
      "statuscode": "302",
      "msg": "By creating an account or logging in, you agree to Volt Panda's Terms of Use and Privacy Policy and consent to the collection and use of your personal information/sensitive personal data or information."
    },
    {
      "statuscode": "303",
      "msg": "Paying via {Paytm}. We will auto redirect you to the UPI App, Please don't close or back up now."
    },
    
  ]