const { ObjectId } = require('mongodb');
const SimController = require('../models/machineControl');
const Machine = require('../models/machine')
const User = require('../models/user');
const { calculateAmountFromEnergy } = require('../services/UserPowerCalculation');
const { recordTransactionOnStop } = require('../controllers/recordTransaction');
const MachineConnectorGun = require('../models/machineConnectorGun');
const { buildConnection } = require('../config/db');
const { UserWallet } = require('../middleware/common')
const { StopCharging_Hardware, connectorLocking_Hardware } = require('../services/hardware/charger')

/**
 * @param {*} data - ChargingSessionId, chargerId(machine serial number)
 * @returns - It Stops the machine which is in charging with 
                ChargingsessionId and return the rest amount to
                user transitwallet. Here charging data will also stored in usercharginghistory and 
                transactions collection.
 */
exports.stopChargingFunc = function (data) {
    return new Promise(async (resolve, reject) => {
        if (data.ChargingSessionId) {
            let id = data.ChargingSessionId;            
            let response = await SimController.find({ ChargingSessionId: id });
            if (!response || response.length == 0) {
                resolve({ Status: 400, Message: "There Is Some Problem : Bad Request", Data: {} });
            } else {
                response = response[0];
                if (response.Status == 1) {
                    let stopStatus = {};
                    if(response.MachineType == 2 || response.MachineType == 3){     //check condition whether a machine is emulator or hardware
                        let newdata = { "transactionId":parseInt(data.ChargingSessionId),"chargerId":data.chargerId}    //input for hardware
                        stopStatus= await StopCharging_Hardware(newdata);       //sent response by hardware at the time of stop
                        console.log("stopStatus",stopStatus);
                    }else{
                        //it will work in the case of simulator only
                        stopStatus.enumStatus = '1';
                    }
                    if(stopStatus.enumStatus == 1 || stopStatus.enumStatus == 2){
                    let output = {};
                    delete data.id;
                    let endtime = Date.now();
                    //to calculate total time lapsed
                    let totalTime = (endtime - parseInt(response.StartTime));
                    data.TotalTime = totalTime;
                    data.endTime = endtime;
                    data.Status = 4;
                    data.timeLeft = 0;
                    let amount = await calculateAmountFromEnergy(response.CurrentEnergy);

                    //Input object for transactio history collection
                    let functionRequestData = {};
                    functionRequestData.UserId = response.UserId;
                    functionRequestData.LocationID = response.LocationID;
                    functionRequestData.MachineId = response.MachineId;
                    functionRequestData.ProductId = amount.ProductId;
                    functionRequestData.Amount = amount.Amount;
                    functionRequestData.ValueCollection = 'chargingstatuses';
                    functionRequestData.ValueColumn = 'ChargingSessionId';
                    functionRequestData.Value = response.ChargingSessionId;
                    functionRequestData.ChargingSessionId = response.ChargingSessionId;
                    functionRequestData.BaseCharge = amount.BaseCharge;
                    //functionRequestData.totalTime = totalTime;
                    functionRequestData.CurrentEnergy = response.CurrentEnergy;

                    functionRequestData.StartTime = response.StartTime;
                    functionRequestData.TotalTime = totalTime;
                    functionRequestData.endTime = endtime;
                    functionRequestData.TargetEnergy = response.TargetEnergy;
                    functionRequestData.FinalEnergy = response.CurrentEnergy;
                    functionRequestData.TotalAmount = amount.Amount;
                    functionRequestData.MachineType = response.MachineType;
                    functionRequestData.ConnectorGunId = response.ConnectorGunId;
                    functionRequestData.TargetAmount = response.TargetAmount;

                    let transaction = await recordTransactionOnStop(functionRequestData)

                    //It will deduct the amount from user wallet and return the rest amount 
                    let resTransDebit = await UserWallet.debitTransitionWalletAmount(response.UserId, amount.Amount);                    
                    if(resTransDebit.enumStatus == 0){
                        return resDeduction;
                    }
                    let resRewindAmount = await UserWallet.rewindTransitionUserAmount(response.UserId);                    
                    if(resRewindAmount.enumStatus == 0){ 
                        return resRewindAmount;
                    }


                    //data.TransID = transaction;
                    data.FinalEnergy = response.CurrentEnergy;
                    data.TotalAmount = amount.Amount;

                    /* deduct amount from user main wallet */
                   // UserWallet.debitMainWalletAmount(data.user_id, data.TotalAmount);

                    /* data.ChargingSessionId = '';
                    data.TransID = ''; */
                    let simController = await SimController.findOneAndUpdate({ _id: ObjectId(response._id) }, data);
                    if (!simController) {
                        resolve({ Status: 200, Message: "Some issue in Stop", Data: {} });
                    } else {

                        output._id = simController._id;
                        output.LocationID = response.LocationID;
                        output.MachineId = response.MachineId;
                        output.TargetEnergy = response.TargetEnergy;
                        output.FinalEnergy = data.FinalEnergy;
                        output.ChargingSessionId = response.ChargingSessionId;
                        output.MachineType = response.MachineType;
                        output.TotalAmount =  data.TotalAmount;
                        const d = new Date();
                        output.StartTime = Math.floor(response.StartTime / 1000);
                        output.StartDate = `${d.getDate()}-${d.getMonth()}-${d.getFullYear()}`;
                        output.TotalTime = Math.floor(totalTime / 1000);
                        output.CloseTime = Math.floor(endtime / 1000);
                        output.CloseDate = `${d.getDate()}-${d.getMonth()}-${d.getFullYear()}`;
                        output.TransID = transaction;
                        if(!stopStatus.Message){
                            stopStatus.Message = 'Simulator charging has been completed';
                        }
                        let db = await buildConnection();
                        //update the machineconnector collection for aviability, so it will show that machine is aviable now for other user use
                        let updateInConnectorModel = await db.collection('machineconnectorguns').updateOne({ _id: ObjectId(response.ConnectorGunId) }, { $set: { "Availability": 1 } })
                        // let updateData = {};
                        // updateData.ChargingSessionId = null;
                        // updateData.TransID = null;

                        //await SimController.findOneAndUpdate({ _id: ObjectId(response._id) }, output);
                       
                        // Delete whole table/document of ChargingStatus (simcontroller)
                        //simController = await SimController.remove({ _id: ObjectId(response._id) });
                        
                        //output.Status = 3;
                        //returnJsonResponse(req, res, { Status: 200, Message: "Success", Data: { _id: simController._id.toString() } });
                        resolve({ Status: 200, Message:`${stopStatus.Message}`, Data: output });
                    }
                }else{
                    resolve({ Status: 200, Message: `${stopStatus.Message}`, Data: {} });
                }
                }
                else {
                    resolve({ Status: 204, Message: "please start your charging", Data: {} });
                }
            }

        } else {
            resolve({ Status: 400, Message: "Bad Request", Data: {} });
        }
    });
}

/**
 * 
 * @param {*} duration - timestamp in millisecond
 * @returns - time in format HH:MM:SS
 */
function msToTime(duration) {
    var milliseconds = parseInt((duration % 1000) / 100),
        seconds = Math.floor((duration / 1000) % 60),
        minutes = Math.floor((duration / (1000 * 60)) % 60),
        hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    return hours + ":" + minutes + ":" + seconds;
}

/**
 * 
 * @param {ObjectId} userid 
 * @param {Number} amount 
 * @returns - It will credit the user wallet when user will make payment
 */
exports.creditUserWalletOnPayment = async function(userid, amount){
    //let data = req.body;
    console.log(userid);
    let userData = await User.findOne({ _id: ObjectId(userid) });
    console.log(userData);
    if (!userData.MainWallet) {
        userData.MainWallet = 0;
    }
    let transitionwallet = (parseFloat(userData.MainWallet) + parseFloat(amount)).toFixed(2);
    userData = await User.findOneAndUpdate({ _id: ObjectId(userid) },
        {
        MainWallet: transitionwallet,
        //TmpWallet: Math.floor(transitionwallet),
        //TransitionWallet: transitionwallet
        });
    // returnJsonResponse(req, res, { Status: 200, Message: "Balance credited", Data: userData });
}

/** 
 * @param {*} data - MachineId,ConnectorID
 * @returns It will add new machine in chargingstatus table and make the connection 
            when machine is working fine
 */
exports.newMachineAdd = async function(data){
    //MachineId,ConnectorID
    
    //It will get data from MachineConnectorGun collection
    let machineConnector = await MachineConnectorGun.find({"_id":ObjectId(data.ConnectorID),"MachineID":ObjectId(data.MachineId)});
    
    //It will get data from machine collection
    let machine = await Machine.findOne({"_id":ObjectId(data.MachineId)})
    if(!machineConnector || machineConnector.length == 0 || !machine || machine.length == 0){
        return {Message: "Machine with This Connector ID Doesnot Exist", Data: ''};
    }else{
        machineConnector = machineConnector[0];
        let machineControll = {}
        machineControll.MachineId = machineConnector.MachineID;
        machineControll.TransID = null;
        machineControll.LocationID = machineConnector.LocationID;
        machineControll.ConnectorGunId = machineConnector._id;
        machineControll.UserId = data.UserId || '';
        //machineControll.Status = "5";
        machineControll.StartTime = 0; 
        machineControll.timeLeft= 0 ;
        machineControll.TotalTime= 0 ;
        machineControll.endTime= 0 ;
        machineControll.ChargingSessionId = "";
        MachineType = machine.MachineType;
        machineControll.MachineType = MachineType;
        TargetEnergy = 0;
        CurrentEnergy = 0;
        FinalEnergy = 0;
        TotalAmount = 0;
        
            let connectionStatus = {}
            if(machine.MachineType == 3 || machine.MachineType == 2){   //it will check machine type as hardware or emulator
                connectionStatus = await connectorLocking_Hardware({"chargerId":machine.MachineSeriealNo}); //send hardware respose for connector locking
            }else{
                connectionStatus.enumStatus = '1';
            }
            if( connectionStatus.enumStatus = 1){
                machineControll.Status = "5";
                let machineAdd = await SimController.create(machineControll);
                return {Message: connectionStatus.Message || "Your Gun has been connected", Data: {"MachineControllerID":machineAdd._id}}; 
            }else{
                return {Message: connectionStatus.Message || "Your Gun has not been connected", Data: {"MachineControllerID":machineAdd._id}};
            }
            
        
    }
}

/**
 * @params {} userid 
 * @params {} userdate - Format will be YYYY-MM-DD
 * @return - it will return the all topup data at particular date 
 */
//Created on 19-08-22- Get top
exports.getTopupByUser = (async (userid, userdate)=>{
    let db = await buildConnection();
    let newDate = new Date(userdate);//Enter Format YYYY-MM-DD
    let dateMax = new Date(userdate);
    dateMax.setUTCHours(23, 59, 59)
    let topup = await db.collection("topuptransactionschemas").aggregate([
            { 
               $match:{"userId":ObjectId(userid),  "AddedDate": { $gte: newDate, $lte: dateMax  }}
                
            },
            { 
                $project: { _id:1, amount:1, tax_amount:1, Status:1, AddedDate:1, totalAmt: { $add: ["$amount", "$tax_amount"] } } 
            }
        ]).toArray();

    if (!topup) {
        return { Status: 500, Message: `No TopUp with this userid ${userid}`, Data: {} };
    }else{
        topup.map((z,i)=>{
            topup[i].TransID = z._id;                                   //Display transaction id as TransID
            delete topup[i]._id;
            topup[i].Date = (z.AddedDate).toISOString().substr(0,10);   //Display date in proper format
            delete topup[i].AddedDate;
            topup[i].amount = (topup[i].amount).toFixed(2);
            topup[i].tax_amount = (topup[i].tax_amount).toFixed(2);
            topup[i].totalAmt = (topup[i].totalAmt).toFixed(2);
        })
        return { Status: 200, Message: "success", Data: topup };
    }  
});


