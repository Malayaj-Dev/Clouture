const {returnJsonResponse} = require('../utils/response');
var admin = require('firebase-admin');
var serviceAccount = require('../config/voltpandaapp.json')

let test  = admin.initializeApp({
    credentials: admin.credential.cert(serviceAccount)
})

module.exports = {    
    validateFirebaseIDToken: async (idToken) => {
        admin.auth()
        .verifyIdToken(idToken)
        .then((decodedToken) => {
            const uid = decodedToken.uid;
            return uid;
            // ...                
        })
        .catch((error) => {
            // Handle error
            //returnJsonResponse(req, res, { Status: 500, Message: "Internal server error (idToken)", Data: error });
        });
    }
}