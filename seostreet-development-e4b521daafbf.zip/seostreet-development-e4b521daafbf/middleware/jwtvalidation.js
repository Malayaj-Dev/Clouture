const jwt = require('jsonwebtoken');
const path = require('path');

module.exports = {
    isLoggedInWeb: (req, res, next) => {
        const token = req.cookies.token;
        if(!token)
        {
          return res.sendFile(path.join(__dirname, '../public/login.html'));
          //return res.sendStatus(403,'You are not validated');
        }
        try {
        //const token = req.headers.authorization.split(' ')[1];
          const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
          );
          req.userData = decoded;
          // console.log(req.userData);
          // console.log(token);
          //return res.sendFile(path.join(__dirname, '../public/dashboard.html'));
          next();
        } catch (err) {
            return res.sendFile(path.join(__dirname, '../public/login.html'));
          // return res.status(401).send({
          //  msg: 'Your session is not valid!'
          // });
        }
      }
    };

