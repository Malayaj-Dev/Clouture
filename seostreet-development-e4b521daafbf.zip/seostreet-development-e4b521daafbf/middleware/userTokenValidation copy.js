const userAuthentication = require('../models/userAuthentication');
const jwt = require('jsonwebtoken');
const {returnJsonResponse} = require('../utils/response');

module.exports = async(req, res, next) => {

    let userResult = {};
    if(!req.headers.token || req.headers.token == undefined || req.headers.token == null || req.headers.token == ''){
        userResult = ({code: 401 ,msg:"Token is required",data:[]});
    }
    else{
        const token = req.headers.token;
        
        jwt.verify(token, process.env.JWT_SECRET_USER, (err, decoded) => {
            console.log(err);
            if (err) {
                //returnJsonResponse(req, res, { Status: 401, Message: "Token Expired", Data: err.name });
                userResult = ({code: 401 ,msg:"Token is Expired",data: err.name });
                 console.log('111',err);
            }
        })
        //console.log('333',  err); 
        
        let where = {token : req.headers.token}
        userAuthentication.findOne({
            where,
          }).then(value => {
              if(!value){
                userResult = (
                  {
                      code    : 401 ,
                      message : "UnAuthorized Token! ",
                      errors  : {}
                  });
              }else{
                  next();
              }
          }).catch(err => {
            userResult = ({code:500,msg:err.message || 'Unable to validate token!'})
          })
        return returnJsonResponse(userResult);
        /* let data = await userAuthentication.findOne({ token : req.headers.token });
        
        if(!data){ 

            //returnJsonResponse(req, res, { Status: 401, Message: "unauthorize token", Data: {} });
         }else{
            console.log(data);
             next()
         } */

        /* let where = {token : req.headers.token}
        userAuthentication.findOne({
          where
        }).then(value => {
            if(!value){ 
               returnJsonResponse(req, res, { Status: 401, Message: "unauthorize token", Data: {} });
            }else{
                next()
            }
        }).catch(err => {
            returnJsonResponse(req, res, { Status: 401, Message: "Unable to validate token!", Data: err.message });
        }) */
    }
};