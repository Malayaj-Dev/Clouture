const userAuthentication = require('../models/userAuthentication');
const jwt = require('jsonwebtoken');
const {returnJsonResponse} = require('../utils/response');

module.exports = async(req, res, next) => {
    if(!req.headers.token || req.headers.token == undefined || req.headers.token == null || req.headers.token == ''){
        return res.json({code: 401 ,msg:"Token is required",data:[]});
    }
    else{
        const token = req.headers.token;
        let userResult = {code: 401 ,msg:"Token is Expired", data: ''};
        jwt.verify(token, process.env.JWT_SECRET_USER, (err, decoded) => {
            if (err) {
                //returnJsonResponse(req, res, { Status: 401, Message: "Token Expired", Data: err.name });
                return res.json({code: 401 ,msg:"Token is Expired",data: err.name });
                // console.log(err);
            }
        })
        //console.log(err); 
        
        let where = {token : req.headers.token}
        userAuthentication.findOne({
            where,
          }).then(value => {
              if(!value){
                  return res.status(422).json(
                  {
                      code    : 401 ,
                      message : "UnAuthorized Token! ",
                      errors  : {}
                  });
              }else{
                  next();
              }
          }).catch(err => {
              return res.json({code:500,msg:err.message || 'Unable to validate token!',data:[]})
          })

        /* let data = await userAuthentication.findOne({ token : req.headers.token });
        
        if(!data){ 

            //returnJsonResponse(req, res, { Status: 401, Message: "unauthorize token", Data: {} });
         }else{
            console.log(data);
             next()
         } */

        /* let where = {token : req.headers.token}
        userAuthentication.findOne({
          where
        }).then(value => {
            if(!value){ 
               returnJsonResponse(req, res, { Status: 401, Message: "unauthorize token", Data: {} });
            }else{
                next()
            }
        }).catch(err => {
            returnJsonResponse(req, res, { Status: 401, Message: "Unable to validate token!", Data: err.message });
        }) */
    }
};