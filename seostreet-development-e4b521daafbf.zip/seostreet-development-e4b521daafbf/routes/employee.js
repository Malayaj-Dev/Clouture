const express = require('express');
const jwtVarify = require('../middleware/jwtvalidation');
const {
  register
} = require('../controllers/employee');

const router = express.Router();

router.post('/addEmp', register);
module.exports = router;