var express = require('express');
var router = express.Router();
const { userRegistration, getAllUser} = require('../controllers/user');

/* GET users listing. */
router.post('/userRegistration', userRegistration);
router.get('/getAllUser', getAllUser);

module.exports = router;
