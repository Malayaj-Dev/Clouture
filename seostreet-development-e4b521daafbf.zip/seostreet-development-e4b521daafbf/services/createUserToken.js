const jwt = require("jsonwebtoken");
const { ObjectId } = require('mongodb');
const userAuthentication = require('../models/userAuthentication');
const { AddMinutesToDate } = require('../middleware/common');

module.exports = {
    /* ***************Function Upload Image**********************************
    * @type            : Function
    * @function name   : Generate JWT Token
    * @description     : this function used to Generate token
    * @param           : secret, expire time
    * @return          : token 
    *********************************************************** */ 
    generateToken: async (id, clientIp, jwtSecretKey, jwtTokenExpire) => {
     
        let user_token = await jwt.sign({
            id: id
          }, jwtSecretKey, {
            expiresIn: jwtTokenExpire // expires in 24 hours
          });
          
          let token_details = await userAuthentication.create(
            {
                userid: ObjectId(id),
                token : user_token,
                IPv4: clientIp,
                userAgent: 'test',
                platForm : 'androide',
                DateTime: new Date(),
                ExpireDateTime: AddMinutesToDate(new Date(), jwtTokenExpire),
                Status: true
            });
        return token_details;
    }
}