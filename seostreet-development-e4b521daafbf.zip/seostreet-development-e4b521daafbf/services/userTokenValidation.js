const userAuthentication = require('../models/userAuthentication');
const jwt = require('jsonwebtoken');
const {returnJsonResponse} = require('../utils/response');

module.exports = (req, res, next) => {
 
    if(!req.headers.token || req.headers.token == undefined || req.headers.token == null || req.headers.token == ''){
        return res.json({code: 401 ,msg:"Token is required",data:[]});
    }
    else{
        const token = req.headers.token;
        jwt.verify(token, process.env.JWT_SECRET_USER, (err, decoded) => {
            if (err) {
                returnJsonResponse(req, res, { Status: 401, Message: "Token Expired", Data: err.name });
            }            
        })

        let where = {USER_TOKEN:req.headers.token}
        userAuthentication.findOne({
          where,
        }).then(value => {
            if(!value){ 
               returnJsonResponse(req, res, { Status: 401, Message: "unauthorize token", Data: {} });
            }else{
                next()
            }
        }).catch(err => {
            returnJsonResponse(req, res, { Status: 401, Message: "Unable to validate token!", Data: err.message });
        })
    }
};