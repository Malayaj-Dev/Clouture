class ErrorResponse extends Error {
    constructor(message, statusCode) {
      super(message);
      this.statusCode = statusCode;
  
      Error.captureStackTrace(this, this.constructor);
    }
  }
// const errorType = require('../data/errorCodes');


// const returnJsonRes = function (req, res, params) {
//     if (!params.Status) {
//         throw new Error("Invalid Response Structure");
//     }
//     errorType.forEach(e => {
//                 if(e.statuscode == params.Status){
//                     res.status(params.OriginalStatus || 200).json({
//                         statusCode: e.statuscode,
//                         message: e.msg,
//                         data: params.Data
//                     });
//                 }
//               });
// };
module.exports = ErrorResponse;
  //module.exports = {returnJsonRes};
  