const returnJsonResponse = function (req, res, params) { 
     
    if (!params.Status || !params.Message) {
        throw new Error("Invalid Response Structure");
    }
    res.status(params.OriginalStatus || 200).json({
        statusCode: params.Status,
        message: params.Message,
        data: params.Data
    });
};

const returnAPPJsonResponse = function (req, res, params) {
    if (!params.Status || !params.Message) {
        throw new Error("Invalid Response Structure");
    }
    res.status(params.OriginalStatus || 200).json({
        statusCode: params.Status,
        message: params.Message,
        result: {
            ErrorCode : params.response.ErroCode,
            data : params.response.Data,
        }
    });
};


module.exports = {returnJsonResponse, returnAPPJsonResponse};